******************SEQUENCES**********************

create sequence REQID start with 1
create sequence ASSET_ID_SEQ
create sequence ASSET_ID_SEQ
create sequence ALLOT_ID_SEQ

******************USER_MASTER *******************

create table User_Master(UserId VARCHAR2(6), 
UserName VARCHAR2(15),
UserPassword VARCHAR2(50),
UserType VARCHAR2(10));

SELECT * FROM USER_MASTER;
update USER_MASTER set userpassword='efgh' where USERID='1007'
select mgr from USER_MASTER a,employee b where a.userId=b.mgr
select count(*) from USER_MASTER where USERID='Sur100' and USERPASSWORD='Sur@123' and usertype='Manager'

insert into user_master values (1002,'Suraj','efgh','MANAGER')
update user_master set usertype = 'ADMIN' where userid = 1000
********************REQUEST**********************

select * from request
create table Request(Reqid number,
mgr number,
Empno number REFERENCES Employee(Empno),
AssetId number REFERENCES Asset(AssetId), 
Quantity number ,
Status varchar2(25),
Release_date DATE );

SELECT EMPNO FROM EMPLOYEE WHERE MGR = 101
delete from request
*******************DEPARTMENT********************

create table Department(Dept_ID number primary key , Dept_Name VARCHAR2(50));
select * from department

insert into department values(103,'Technology')


*******************EMPLOYEE**********************

create table Employee(Empno Number primary key,Ename Varchar2(25),job Varchar2(50),mgr number,
hiredate DATE, Dept_ID number REFERENCES Department(Dept_ID));
select * from EMPLOYEE





********************ASSET***************************

create table Asset(AssetId Number primary key,
AssetName Varchar2(25),
AssetDes Varchar2(25),
Quantity Number,
Status Varchar2(15))

select * from ASSET

update asset set quantity = 30 where assetid=2


******************ASSET_ALLOCATION*******************

create table Asset_Allocation(AllocationId Number primary key, 
AssetId Number REFERENCES Asset(AssetId),
Empno Number REFERENCES Employee(Empno),
Allocation_date DATE,
Release_date DATE);

select * from Asset_Allocation


SELECT * FROM REQUEST WHERE MGRNO =(SELECT USERID FROM USER_MASTER WHERE USERID=?)
SELECT userid FROM USER_master WHERE USERID=1002

