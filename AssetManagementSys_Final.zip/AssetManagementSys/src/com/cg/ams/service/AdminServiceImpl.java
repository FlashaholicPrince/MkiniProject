package com.cg.ams.service;

import java.util.ArrayList;

import java.util.HashMap;


import com.cg.ams.bean.Asset;
import com.cg.ams.bean.Request;
import com.cg.ams.dao.*;
import com.cg.ams.exception.*;


public class AdminServiceImpl implements AdminService{

	AdminDao dao;
	public void setDao(AdminDao dao)
	{
		this.dao = dao;
	}
	public AdminServiceImpl()
	{
		dao=new AdminDaoImpl();
	}
	
	@Override
	public boolean addAsset(Asset asset) throws AdminException {
		// TODO Auto-generated method stub
		return dao.addAsset(asset);
	}

	@Override
	public boolean modifyAsset(Asset asset) throws AdminException {
		// TODO Auto-generated method stub
		return dao.modifyAsset(asset);
	}

	@Override
	public ArrayList<Request> viewRequest() {
		// TODO Auto-generated method stub
		return dao.viewRequest();
	}

	@Override
	public boolean acceptRequest(int reqId) throws AdminException {
		// TODO Auto-generated method stub
		return dao.acceptRequest(reqId);
	}

	@Override
	public boolean rejectRequest(int reqId) throws AdminException {
		// TODO Auto-generated method stub
		return dao.acceptRequest(reqId);
	}

	@Override
	public HashMap<Integer, Request> viewAllRequest() throws AdminException {
		// TODO Auto-generated method stub
		return dao.viewAllRequest();
	}

	@Override
	public boolean acceptManagerRequest(int key) throws AdminException {
		// TODO Auto-generated method stub
		return dao.acceptManagerRequest(key);
	}

	@Override
	public boolean rejectManagerRequest(int key) throws AdminException {
		// TODO Auto-generated method stub
		return dao.rejectManagerRequest(key);
	}

	@Override
	public boolean validateAdmin(String userid, String pwd, String usertype) throws AdminException{
		// TODO Auto-generated method stub
		return dao.validateAdmin(userid,pwd,usertype);
	}

	
	@Override
	public boolean validateAssetId(int assetId) throws AdminException {
		// TODO Auto-generated method stub
		return dao.validateAssetId(assetId);
	}

	@Override
	public HashMap<Integer, Asset> viewAssets() throws AdminException {
		// TODO Auto-generated method stub
		return dao.viewAssets();
	}
	@Override
	public Asset getAssetDetails(int assetId) throws AdminException {
		// TODO Auto-generated method stub
		return dao.getAssetDetails(assetId);
	}

}
