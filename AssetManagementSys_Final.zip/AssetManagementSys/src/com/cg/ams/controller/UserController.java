package com.cg.ams.controller;

import java.io.IOException;





import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/UserController")
public class UserController extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
    public UserController() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		
		String userid = request.getParameter("id");
		
		String usertype=request.getParameter("usertype");
		HttpSession session = request.getSession();
		
				
		if("admin".equalsIgnoreCase(usertype))
		{
			
			session.setAttribute("userId", userid);
			getServletContext().getRequestDispatcher("/AdminController?action=AdminLogin").forward(request, response);
		}
		
		else if("manager".equalsIgnoreCase(usertype))
		{
		
			session.setAttribute("userId", userid);
			getServletContext().getRequestDispatcher("/ManagerController?action=ManagerLogin").forward(request, response);
		}
		
		
	}

}
