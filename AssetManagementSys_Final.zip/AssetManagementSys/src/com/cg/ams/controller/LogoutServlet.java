package com.cg.ams.controller;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/logout")
public class LogoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public LogoutServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	
	public void destroy() {
		// TODO Auto-generated method stub
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
		 HttpSession session = request.getSession(false);
		 System.out.println("sessio is"+session);

	        if(session!=null){

	            session.invalidate();
	            session=null;
	            System.out.println("session1 is"+session);
	        }
	        
	        System.out.println("sessio2 is"+session);
	        request.getRequestDispatcher("/index.jsp").forward(request, response);
		
		
		/*
	     HttpSession session=request.getSession(false); 
	     System.out.println("sessio is"+session);
	     System.out.println(session.getId());
		 session.invalidate();
		 request.getRequestDispatcher("/index.jsp").forward(request, response);*/
	       
	}

}
