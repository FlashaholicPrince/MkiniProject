package com.cg.ams.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.cg.ams.bean.Asset;
import com.cg.ams.bean.Request;
import com.cg.ams.exception.*;
import com.cg.ams.logger.*;
import com.cg.ams.util.*;



public class ManagerDaoI implements ManagerDao {
	
	Connection connection;
	PreparedStatement pstat;
	ResultSet rset;
	static Logger  mylogger=DaoLogger.mylogger;
	public ManagerDaoI()
	{
		try {
			connection = DBUtil.getConnect();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public boolean validateManager(String userid, String pwd, String usertype) throws ManagerException {
		boolean flag = false;
		
		
		try {
			
			connection = DBUtil.getConnect();
			String sql="select count(*) from USER_MASTER where USERID=? and USERPASSWORD=? and usertype=?";
			
			pstat = connection.prepareStatement(sql);
			pstat.setString(1, userid);
			pstat.setString(2, pwd);
			pstat.setString(3, usertype);
			rset = pstat.executeQuery();
			rset.next();
			
			int count=rset.getInt(1);
			
			if(count ==1)
			{
				flag = true;
				
			}
			else 
			{
				mylogger.error("not valid manager");

				throw new ManagerException("not valid manager");
		}
			
		} 
		
		
		catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new ManagerException("SQL EXCEPTION");
		}
		
		finally{
			try{
			rset.close();
			pstat.close();
			connection.close();
			}
		catch (SQLException e) {
		
			e.printStackTrace();
		}
		}
		return flag;
	}
	
	@Override
	public HashMap<Integer, Asset> viewAssets() throws ManagerException {
		// TODO Auto-generated method stub
		
		HashMap<Integer,Asset> map = new HashMap<Integer,Asset>();
		
		String qry="SELECT * FROM ASSET WHERE STATUS='AVAILABLE'";
		
		try
		{
			pstat=connection.prepareStatement(qry);
			ResultSet res=pstat.executeQuery();
			
			while(res.next())
			{
				
				Asset obj1=new Asset();
				obj1.setAssetId(res.getInt(1));
				obj1.setAssetName(res.getString(2));
				obj1.setAssetDes(res.getString(3));
				obj1.setAssetQuantity(res.getInt(4));
				obj1.setAssetStatus(res.getString(5));
				map.put(res.getInt(1), obj1);//add to list all these above fields
			
			}
			if(map.size()==0)
			{
				mylogger.error("unable to fetch record");

				throw new ManagerException(" not Available!");
			}
			else
			{
				mylogger.info(map);
			}
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			throw new ManagerException("SQL EXCEPTION");
		}
		
		return map;
	}
	
	
	@Override
	public ArrayList<Integer> getEmployees(int mgrNo) throws ManagerException 
	{
	ArrayList<Integer> list1= new ArrayList<Integer>();
	try
	{
		String qry=" SELECT EMPNO FROM EMPLOYEE WHERE MGR = ?";

		pstat=connection.prepareStatement(qry);
		pstat.setInt(1, mgrNo);
		ResultSet res=pstat.executeQuery();
		
		while(res.next())
		{
			list1.add(res.getInt(1));//add to list all these above fields
		}
		
		if(list1.size()==0)
		{
			throw new ManagerException(" no such emp for the given manager");
		}
		
	}
	catch(SQLException e)
	{
		throw new ManagerException("SQL EXCEPTION");
	}
	return list1;
		
	}
	
	@Override
	public boolean insertFormDetails(Request req) throws ManagerException {
		// TODO Auto-generated method stub
		
		boolean flag=false;
		int reqId;
		String seq = "select REQID.nextVal from dual";
		
		String qry	="INSERT INTO Request VALUES(?,?,?,?,?,?,?)";
		try
		{
			Statement st = connection.createStatement();
			rset = st.executeQuery(seq);
			rset.next();
			reqId = rset.getInt(1);
			req.setReqId(reqId);
			
			pstat=connection.prepareStatement(qry);
			pstat.setInt(1,reqId );
			pstat.setInt(2,req.getMgrNum() );
			pstat.setInt(3,req.getEmpNo() );
			pstat.setInt(4,req.getAssetId());
			pstat.setInt(5,req.getAssetQuantity());
			pstat.setString(6, req.getStatus() );
			pstat.setDate(7,req.getReleaseDate());
			
			int row =pstat.executeUpdate();
			if(row>0)
			{
				flag =true;
				mylogger.info("Data inserted successfull with request id"+reqId);
			}
			else
			{
				mylogger.error("unable to insert record");

			}
		}
			
			catch(SQLException e)
			{
				throw new ManagerException("SQL EXCEPTION");
			}
	
		
		return flag;
	}


	@Override
	public HashMap<Integer, Request> viewStatus(int userId) throws ManagerException  {
		// TODO Auto-generated method stub
		
		HashMap<Integer,Request> map = new HashMap<Integer,Request>();
		
		String qry="SELECT * FROM REQUEST WHERE MGR =(SELECT USERID FROM USER_MASTER WHERE USERID=?)";
		
		try
		{
			pstat=connection.prepareStatement(qry);
			pstat.setInt(1, userId);
			ResultSet res=pstat.executeQuery();
			
			
			while(res.next())
			{
				Request obj=new Request();
				int rId=res.getInt(1);
				obj.setReqId(res.getInt(1));
				obj.setMgrNum(res.getInt(2));
				obj.setEmpNo(res.getInt(3));
				obj.setAssetId(res.getInt(4));
				obj.setAssetQuantity(res.getInt(5));
				obj.setStatus(res.getString(6));
				obj.setReleaseDate(res.getDate(7));
				map.put(rId, obj);//add to list all these above fields
			
			}
			
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			throw new ManagerException("SQL EXCEPTION");
		}
		
		
		
		return map;
	}


	
	
	@Override
	public boolean deleteRequest(int reqId) throws ManagerException {
		// TODO Auto-generated method stub
		boolean flag=false;
		
		String qry="DELETE FROM REQUEST WHERE REQID=?";
		
		try
		{
			pstat=connection.prepareStatement(qry);
			pstat.setInt(1,reqId);
			int row=pstat.executeUpdate();
			if(row>0)
			{
				
				flag=true;
				mylogger.info("request deleted");
			}
			else
			{
				mylogger.error("REQID is not correct");

				throw new ManagerException("enter valid REQID");
			}
		}
			catch(SQLException e)
			{
				throw new ManagerException("SQL EXCEPTION");
			}
		return flag;
	}

	private int getReqId() throws ManagerException {
		int rId=0;
		String qry="SELECT REQ_ID_SEQ.nextval from dual";
		PreparedStatement pstmt;
		try {
			pstmt = connection.prepareStatement(qry);
			ResultSet res=pstmt.executeQuery();
			if(res.next())
			{
				rId=res.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
			throw new ManagerException("SQL EXCEPTION");
		}
		
		return rId;
	}


	@Override
	public int getManagerNumber(int userId) throws ManagerException
	{
		int mgr=0;
		String qry="select mgr from USER_MASTER a,employee b where a.userId=b.mgr";
		try{
		pstat = connection.prepareStatement(qry);
		pstat.setInt(1, userId);
		ResultSet res = pstat.executeQuery();
		
		while(res.next())
		{
			mgr=res.getInt(1);
		}
		}
		catch(SQLException e)
		{
			throw new ManagerException("SQL EXCEPTION");
		}
		return mgr;
	}
	
	
}