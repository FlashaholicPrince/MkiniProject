package com.cg.ams.dao;


import java.util.ArrayList;


import java.util.HashMap;
import com.cg.ams.bean.Asset;
import com.cg.ams.bean.Request;

import com.cg.ams.exception.ManagerException;

public interface ManagerDao {
	

	public boolean insertFormDetails(Request req) throws ManagerException;
	boolean deleteRequest(int reqId) throws ManagerException;
	public HashMap<Integer, Request> viewStatus(int userId) throws ManagerException;
	
	HashMap<Integer, Asset> viewAssets() throws ManagerException;
	boolean validateManager(String userid, String pwd, String usertype) throws ManagerException;
	int getManagerNumber(int userId) throws ManagerException;
	ArrayList<Integer> getEmployees(int mgrNo) throws ManagerException;

}
